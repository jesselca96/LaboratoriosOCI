# Descripción general
Esta es una configuración de Terraform que crea el servicio de red  en Oracle Cloud Infrastructure.

El código de Terraform se usa para crear una pila de Resource Manager, que crea los recursos necesarios y configura la aplicación en los recursos creados.

## Crear
[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/jesselca96/LaboratoriosOCI/blob/3759bd1b2256fd2d621bd2f27bbada08e6f75f3a/Terraforms/Zips/Networking.zip)

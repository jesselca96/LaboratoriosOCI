# Descripción general
Esta es una configuración de Terraform que crea el servicio de red en Oracle Cloud Infrastructure.

El código de Terraform se usa para crear una pila de Resource Manager, que crea los recursos necesarios y configura la aplicación en los recursos creados.